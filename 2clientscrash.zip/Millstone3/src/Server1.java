import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

    


class t extends Thread{
	private int close=0;
	private InputStream is ;
	private ObjectInputStream ois ;
	private ObjectOutputStream oo;
    private Socket s;
    private  String[] a;
    private BufferedReader r;
    private PrintWriter w;
    private static ArrayList queue = new ArrayList();
    private static Map<String, PrintWriter> data = new HashMap<String, PrintWriter>();
        
    
    public t(Socket s){
        this.s=s;
    }
    @Override
    public void run(){
        try{
        OutputStream oss = s.getOutputStream();
       	 oo = new ObjectOutputStream(oss);
        InputStreamReader fr = new InputStreamReader(s.getInputStream());
        r = new BufferedReader(fr);
            
        OutputStreamWriter fw = new OutputStreamWriter(s.getOutputStream());
        w = new PrintWriter(fw);
        JoinResponse(s);
        while(true){
            String st =r.readLine();
            queue.add(st);
    		a = st.split(" ");
    		for(int i=0;i<a.length;i++){
    			System.out.println(i+ ":"+ a[i]);
    		}
    		String path = "C:/users/Karim/Desktop/docroot/";
    		File f = new File(path+a[1]+"."+a[4]);
    		if(f.exists()){
    			
    		byte[] tosend = Files.readAllBytes(Paths.get(path+a[1]+"."+a[4]));
    		ArrayList al = new ArrayList();
    		al.add(tosend);
    		al.add(a[4]);
    		al.add(a[1]);
    		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    		al.add("200 OK");
    		al.add(a[2]);
    		al.add(timestamp);
    		al.add(a[5]);
    		if(a[5].equals("Close")){

        		al.add(close+1);
    		}
    		else{
        		al.add(close);
    		}
    		oo.writeObject(al);
    		oo.flush();
    		
    		
    		
    		}
    		else{
    			System.out.println("Not found");
            	ArrayList al = new ArrayList();
            	byte[] tosend = new byte[1];
        		al.add(tosend);
        		al.add(a[4]);
        		al.add("Not found");
        		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        		al.add("404 Not Found");
        		al.add(a[2]);
        		al.add(timestamp);
        		al.add(a[5]);
        		if(a[5].equals("Close")){

            		al.add(close+1);
        		}
        		else{
            		al.add(close);
        		}
        		oo.writeObject(al);
        		oo.flush();
        	
        		
    		}
    		
    		
    		
    	
    		
    		
    		queue.remove(0);
    		
        }
        
        }
        catch(IOException ex){
        	System.out.println("hena??");
        	System.out.println(ex.getMessage());

    		
    		
        }
        catch(Exception ex){
           System.out.println(ex.toString());
        }
//        run();
    }
	private void JoinResponse(Socket s) {
		String st1;
		try {
			st1 = r.readLine();
			for (Entry<String, PrintWriter> entry : data.entrySet()) {
				String ss;
			    ss =  entry.getKey();
			    if(st1.equals(ss)){
			    	System.out.println("This nickname already exists");
			    	s.close();
			    	return;
			    }
			    
			}
//			queue.add(st1);
			data.put(st1, w);
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
//	private void MemberListResponse(ArrayList a) {
//		String st="The Member List is :"+'\n';
//
//		for (Entry<String, PrintWriter> entry : data.entrySet()) {
//		    st +=  entry.getKey()+'\n';
//		    
//		}
//		st+="-----------------------------";
//		data.get((String)a.get(1)).println(st);
//		data.get((String)a.get(1)).flush();
//		
//	}
    
    
}










public class Server1 {

    public static void main(String[] args) {
       try{
//    	   	pt p = new pt();
//    	   	p.start();
            ServerSocket ss = new ServerSocket(6000);
            while(true){
                Socket s = ss.accept();
                t th = new t(s);
                th.start();
            }
            
            
            
            
            
        }
        catch(Exception ex){
            
        }
    }
    
}
