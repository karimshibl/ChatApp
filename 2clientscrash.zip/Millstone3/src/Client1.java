import java.awt.*;

import javafx.scene.control.ComboBox;

import javax.swing.*;

import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.ArrayList;
class ChatFrame extends JFrame implements ActionListener, Runnable {
//private JTextField txtToSend = new JTextField(25);
private JTextArea txtHistory = new JTextArea();
private int numberofsends=0;
private String path;
//private JScrollPane sp = new JScrollPane(txtHistory);
private JButton btn = new JButton("Request");
private JButton btndown = new JButton("download");
private JPanel pnlSouth = new JPanel();
private JPanel pnltop = new JPanel();
private JPanel pnl1 = new JPanel();
private JPanel pnl2 = new JPanel();
private JPanel pnl3 = new JPanel();
private JLabel label1 =new JLabel("URL : ");
private JLabel label2 =new JLabel("Connection : ");
private JLabel label3 =new JLabel("Format : ");
private Socket s;
private InputStream is;
private ObjectInputStream ois;
private PrintWriter pw;
private BufferedReader br;
private String nickname;
private JCheckBox t1;
private JCheckBox t2;
private JCheckBox t3;
private JCheckBox t4;
private ButtonGroup gt;
private JCheckBox c1;
private JCheckBox c2;
private ButtonGroup gc;
private int close=0;
String[] names = {"album1","album2","Logo1","Logo2","Text1","Text2","Text3","Text4","Video1","Video2"};
private JComboBox cb;
public ChatFrame()  {
join(JOptionPane.showInputDialog(this, "Please Choose a NickName", "NickName", JOptionPane.QUESTION_MESSAGE));
t1 = new JCheckBox("png");
t2 = new JCheckBox("jpg");
t3 = new JCheckBox("mp4");
t4 = new JCheckBox("txt");
c1 = new JCheckBox("keep-alive");
c2 = new JCheckBox("Close");
gt = new ButtonGroup();
gc = new ButtonGroup();
gt.add(t1);
gt.add(t2);
gt.add(t3);
gt.add(t4);
gc.add(c1);
gc.add(c2);
cb = new JComboBox(names);
cb.addActionListener(this);
cb.setSelectedIndex(0);
initialize();
}
public void run() {
try {
while (true) {
	Object o = ois.readObject();
	ArrayList a = (ArrayList) o;
	byte[] recived = (byte[]) a.get(0);
	String format = (String) a.get(1);
	String file_name = (String) a.get(2);
	String status = (String) a.get(3);
	String version = (String) a.get(4);
	Timestamp timestamp = (Timestamp)a.get(5);
	String connection = (String) a.get(6);
	close = (int) a.get(7);
	if(file_name.equals("Not found")){
		btndown.setEnabled(false);
		JOptionPane.showMessageDialog(this, status+ "    " +version+'\n'+timestamp.toString()+'\n'+format+'\n'+connection , "Error", JOptionPane.ERROR_MESSAGE);
		if(close==1)
			s.close();
	}
	else{
	Files.write(Paths.get("C:/Users/Karim/Desktop/Test/" +file_name+"." +format), recived);
	path = "C:/Users/Karim/Desktop/Test/" +file_name+"." +format;
	btndown.setEnabled(true);
	JOptionPane.showMessageDialog(this, status+ "    " +version+'\n'+timestamp.toString()+'\n'+format+'\n'+connection , "Success", JOptionPane.PLAIN_MESSAGE);
	if(close==1){
		btn.setEnabled(false);
	}
	}
}
} catch (IOException ex) {
JOptionPane.showMessageDialog(this, "Disconnected FromServer", "Error", JOptionPane.ERROR_MESSAGE);
System.exit(0);
} catch (ClassNotFoundException e) {
	System.out.println("class not found");
	e.printStackTrace();
}
}
public void initialize() {
this.setTitle("Chatting: " + nickname);
this.setSize(400, 300);
this.setLocation(200, 15);
this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
Container c = this.getContentPane();
c.setLayout(new GridLayout(4,0));
c.add(pnltop);
c.add(pnlSouth);
c.add(btn);
c.add(btndown);
btndown.setEnabled(false);
pnltop.setLayout(new FlowLayout());
pnltop.add(label1);
pnltop.add(cb);
pnlSouth.setLayout(new GridLayout(0,2));
pnlSouth.add(pnl1);
pnlSouth.add(pnl2);
pnl1.setLayout(new GridLayout(3,0));
pnl1.add(label2);
pnl1.add(c1);
pnl1.add(c2);
pnl2.setLayout(new GridLayout(2,0));
pnl2.add(label3);
pnl2.add(pnl3);
pnl3.setLayout(new GridLayout(2,2));
pnl3.add(t1);
pnl3.add(t2);
pnl3.add(t3);
pnl3.add(t4);
//pnlSouth.add(txtToSend);
//pnlSouth.add(btn);
//c.add(BorderLayout.CENTER, sp);
//txtHistory.setEditable(false);
btn.addActionListener(this);
btndown.addActionListener(this);
//txtToSend.addActionListener(this);
}
public void actionPerformed(ActionEvent evt) {
	Object o = evt.getSource();
//String st = txtToSend.getText();
String url=(String)cb.getSelectedItem();
String connection="";
String type="";
boolean flag=true;
if(o==btn){
	System.out.println("dost req");
if(t1.isSelected()){
 type = t1.getText();   	
}
else if(t2.isSelected()){
	 type = t2.getText();   	
	}
else if(t3.isSelected()){
	 type = t3.getText();   	
	}
else if(t4.isSelected()){
	 type = t4.getText();   	
	}
else{
	JOptionPane.showMessageDialog(this, "You Didn't choose the type", "Error", JOptionPane.ERROR_MESSAGE);
	flag=false;
}
if(c1.isSelected()){
	 connection = c1.getText();   	
	}
else if(c2.isSelected()){
		 connection = c2.getText();   	
}
else{
		JOptionPane.showMessageDialog(this, "You Didn't choose connection type", "Error", JOptionPane.ERROR_MESSAGE);
		flag=false;
}
if(flag==true){
	if(numberofsends==0){
pw.println('\n'+"GET "+url + " HTTP/1.1 " + "Hypnotised " + type + " " + connection);
numberofsends++;
System.out.println("ba3at");
	}
	else{
		pw.println("GET "+url + " HTTP/1.1 " + "Hypnotised " + type + " " + connection);
		numberofsends++;
		System.out.println("ba3at");
	}
	
pw.flush();
}
}
else if(o==btndown){
	 Process p;
	try {
		p = Runtime
		         .getRuntime()
		         .exec("rundll32 url.dll,FileProtocolHandler " + path);
				p.waitFor();
	} catch (IOException | InterruptedException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	//System.out.println("open");
	if(close==1){
		try {
			s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
}
public void join(String ss){
	nickname=ss;
	try {
		s = new Socket("127.0.0.1", 6000);
		pw = new PrintWriter(s.getOutputStream());
		br = new BufferedReader(new
		InputStreamReader(s.getInputStream()));
		is = s.getInputStream();
        ois = new ObjectInputStream(is);
		Thread t = new Thread(this);
		t.start();
		} catch (IOException ex) {
		JOptionPane.showMessageDialog(this, "Can't Connect ToServer", "Error", JOptionPane.ERROR_MESSAGE);
		System.exit(0);
		}

}
}
public class Client1 {
public static void main(String[] args) {
ChatFrame f = new ChatFrame();
f.setVisible(true);
}
}