import java.util.ArrayList;


public class A {
public static ArrayList queue = new ArrayList();
}
